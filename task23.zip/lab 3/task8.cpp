#include <iostream>;
using namespace std;
int main()
{
	float radius, area,pi ;
	pi = 3.14;
	cout << " enter the radius";
	cin >> radius;
	area = pi * radius *radius;
	cout << " the area of a cicle is " << area;
	return 0;
}