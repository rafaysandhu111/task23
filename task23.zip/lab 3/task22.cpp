#include <iostream>
using namespace std;
int main()
{
	int weight, height;
	cout << "enter the weight in kilograms = ";
	cin >> weight;
	cout << "enter the hieght in meters = ";
	cin >> height;
	double BGMI = weight / (height * height);
	cout << "the BGMI = " << BGMI;
	return 0;

}