#include <iostream>
using namespace std;
int main()
{
	int n, square, cube;
	cout << "enter the number = "<<endl;
	cin >> n;
	square = n * n;
	cube = n * n * n;
	cout << "No     " << "square     " << "cube     " << endl;
	cout <<  n <<"     " << square << "       "<< cube<<endl;
	cout << n + 1  << "     " << (n+1)*(n+1)<<  "       " << (n+1)*(n+1)*(n+1) << endl;
	cout << n + 2 << "       " << (n + 2) * (n + 2) << "       " << (n + 2) * (n + 2) * (n + 2) << endl;
	cout << n + 3 << "       " << (n + 3) * (n + 3) << "       " << (n + 3) * (n + 3) * (n + 3) << endl;
	cout << n + 4 << "       " << (n + 4) * (n + 4) * (n + 4) << "       " << (n + 4) * (n + 4) * (n + 4) << endl;
	cout << n + 5 << "       " << (n + 5) * (n + 5) << "       " << (n + 5) * (n + 5) * (n + 5) << endl;
	return 0;

	
}
