#include <iostream>
using namespace std;
int main()
{
	double volume, surface, radius, height;
	double pi = 3.14;
	cout << "enter the radius of cylinder = ";
	cin >> radius;
	cout << " enter the hieght of cylinder = ";
	cin >> height;
	volume = pi * radius * radius * height;
	surface = 2 * pi * radius * (radius + height);
	cout << "the volume of cylinder = " << volume << endl;
	cout << "the surface area of cylinder = " << surface << endl;
	return 0;
	

}