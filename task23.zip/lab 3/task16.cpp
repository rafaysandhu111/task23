#include <iostream>
using namespace std;
int main()
{
	int gallons = 12, miles = 350;
	int permile;
	permile = miles / gallons;
	cout << "the number of of miles per gallon = " << permile;
	return 0;

}