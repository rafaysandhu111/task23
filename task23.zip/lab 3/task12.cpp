#include <iostream>
using namespace std;
int main()
{
	int chemistry, physics, maths,total;
	cout << " enter value of chemistry =";
	cin >> chemistry;
	cout << " enter value of maths =";
	cin >> maths;
	cout << " enter value of physics =";
	cin >> physics;
	total = maths + physics + chemistry;
	cout << "________________________________________________"<<endl;
	cout << "MATHS" << "     " << "CHEMISTRY" << "     " <<"PHYSICS"<<"     "<<"TOTAL"<<endl;
	cout << maths << "          " << chemistry << "          " << physics << "          " << total<<endl;
	cout << "________________________________________________";
	return 0;
}