#include <iostream>
using namespace std;
int main()
{
	double hours, minutes, total;
	cout << " enter hours = ";
	cin >> hours;
	cout << "enter minutes = ";
	cin >> minutes;
	total = (hours * 60) + minutes;
	cout << "THE TOTAL MINUTES ARE =  " << total;
	return 0;






}