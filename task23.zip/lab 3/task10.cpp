#include <iostream>
using namespace std;
int main()
{
	int minutes, hours, min;
	cout << "enter the minutes";
	cin >> minutes;
	hours = minutes / 60;
    min =   minutes %  60;
	cout << "hours= " << hours;
	cout << "minutes= " << min;
	return 0;
}
