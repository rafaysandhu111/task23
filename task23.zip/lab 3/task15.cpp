#include <iostream>
using namespace std;
int main()
{
	int fuel, rent, bills,total;
	cout << "enter value of fuel : ";
	cin >> fuel;
	cout << "enter value of rent : ";
	cin >> rent;
	cout << "enter value of bills : ";
	cin >> bills;
	total = fuel + rent + bills;
	cout << "____________________"<<endl;
	cout << "fuel :" << "          " << fuel<<endl;
	cout << "rent :" << "          " << rent << endl;
	cout << "bills :"<<"         "<< bills << endl;
	cout << "total" << "           " << total << endl;
	cout << "____________________";
	return 0;




}