#include <iostream>
using namespace std;
int main()
{
	int price,value, quantity;
	cout << "Enter price of Wheat : ";
	cin >> price;
	cout << "Enter quantity of wheat : ";
	cin >> quantity;
	cout << "Enter price of rice : ";
	cin >> price;
	cout << "Enter quantity of rice : ";
	cin >> quantity;
	cout << " Enter price of sugar : ";
	cin >> price;
	cout << "Enter quantity of sugar : ";
	cin >> quantity;
	value = price * quantity;
	cout << "____________________________"<<endl;
	cout << "Value of wheat : "<<value<< endl;
	cout << "Value of rice :  "<< value<<endl;
	cout << "Value of sugar : "<<value<<endl;
	cout << "____________________________";



	return 0;
}