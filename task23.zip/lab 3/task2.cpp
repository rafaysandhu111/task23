#include <iostream>
using namespace std;
int main()
{
	cout << "Hello Class!" << endl << "Welcome to the ITC-Lab Week 03";
	return 0;
}