#include <iostream>
using namespace std;
int main()

{
	int num1, num2, remainder;
	cout << "enter the 1st number = ";
	cin >> num1;
	cout << "enter the 2nd number =";
	cin >> num2;
	remainder = num1 % num2;
	cout << "the remainder of following numbers =" << remainder;
	return 0;
}
