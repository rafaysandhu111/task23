#include <iostream>
using namespace std;
int main()
{
	int speed = 20, time = 10, distance;
	distance = speed * time;
	cout << "the total distance covered = " << distance;
	return 0;

}