#include <iostream>
using namespace std;
int main()
{
	const int basic_cost = 500, adv_cost = 1000, pro_cost = 2000;
	int benroll, aenroll, penroll;
	cout << "enter the enrollment in basic course =";
	cin >> benroll;
	cout << "enter the enrollment in adv course = ";
	cin >> aenroll;
	cout << "enter the enrollments in pro course = ";
	cin >> penroll;
	double total = ((basic_cost * benroll) + (adv_cost * aenroll) + (pro_cost * penroll)) * 0.85;
	cout << "the total amount with discount = " << total;
	return 0;

}