#include <iostream>
using namespace std;
int main()
{
	double width, length, area, perimeter;
	cout << " enter the width=";
	cin  >> width;
		cout << " enter the length=";
	cin >> length;
	area = width * length;
	cout << "the area of rectangle" << area<<endl;
	perimeter = 2 * (width + length);
	cout << " the perimeter of rectangle is" << perimeter;
	return 0;



}