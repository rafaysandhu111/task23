#include <iostream>
using namespace std;
int main()
{
	int costA = 15, costB = 12, costC = 9;
	int ticketsA,ticketsB,ticketsC, incomeA,incomeB,incomeC, total;
	cout << "enter the tickets of class A = ";
	cin >> ticketsA;
	cout << "enter the tickets of class B = ";
	cin >> ticketsB;
	cout << "enter the tickets of class C = ";
	cin >> ticketsC;
	incomeA = costA *ticketsA;
	incomeB = costB * ticketsB;
	incomeC = costC * ticketsC;
	total = incomeA + incomeB + incomeC;
	cout << "the total income generated = "<<total;
		return 0;


}