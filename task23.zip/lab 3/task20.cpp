#include <iostream>
using namespace std;
int main()
{
	const int g_cost = 50, s_cost = 30, f_cost = 20;
	int g_sold, s_sold, f_sold;





	cout << "enter the number of gourmet meals sold = ";
	cin >> g_sold;
	cout << "enter the number of standard meals sold = ";
	cin >> s_sold;
	cout << " enter the number of fastb meals sold = ";
	cin >> f_sold;
	double total = (g_sold * g_cost) + (s_cost * s_sold) + (f_cost * f_sold);
	cout << "the total income generated = " << total;
	return 0;




}