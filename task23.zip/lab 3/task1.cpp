#include <iostream>;
using namespace std;
int main()
{
	int value;
	cout << "enter variable value = ";
	cin >> value;
	return 0;

}