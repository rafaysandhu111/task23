#include <iostream>
using namespace std;
int main()
{
	int score1, score2, score3, score4, score5, average;

	cout << "enter the 1st score";
	cin >> score1;
	cout << "enter the 2nd score";
	cin >> score2;
	cout << "enter the 3rd score";
	cin >> score3;
	cout << "enter the 4th score";
	cin >> score4;
	cout << "enter the 5th score";
	cin >> score5;
	average = (score1 + score2 + score3 + score4 + score5) / 5 * 100;
	cout << "the average of five test scores = " << average;
	return 0;

}