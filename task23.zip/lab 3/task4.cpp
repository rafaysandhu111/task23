#include <iostream>
using namespace std;

int main()
{
	double weight, height, bmi;

	// Prompt the user to enter weight in kilograms
	cout << "Enter your weight in kilograms: ";
	cin >> weight;

	// Prompt the user to enter height in meters
	cout << "Enter your height in meters: ";
	cin >> height;

	// Calculate BMI
	bmi = weight / (height * height);

	// Display the BMI
	cout << "Your BMI is: " << bmi << endl;

	return 0;
}
